import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AcountService } from '../Service/acount.service';
@Component({
  selector: 'app-sign-up-user',
  templateUrl: './sign-up-user.component.html',
  styleUrls: ['./sign-up-user.component.css']
})
export class SignUpUserComponent implements OnInit{
  signupusers: object[] = [];
  signupobj: any = {
    name: '',
    email: '',
    password: '',
    contect: '',
  };
  loginObj: any = {
    email: '',
    password: '',
  };
pass: any;

  constructor(private AcountService: AcountService, private route: Router) {}

  ngOnInit(): void {
    const localData = localStorage.getItem('signupusers');
    if (localData != null) {
      this.signupusers = JSON.parse(localData);
    }
  }
  onSignUp() {
    console.log(this.signupobj);

    
    
    this.signupusers.push(this.signupobj);
    localStorage.setItem('signupusers', JSON.stringify(this.signupusers));
    
    console.log(this.signupobj)
    this.AcountService.onSignup(this.signupobj).subscribe((res: any) => {
    
      console.log('res', res);
      localStorage.setItem('token', res.token);
      this.route.navigateByUrl('/home');
    });
  }

}
