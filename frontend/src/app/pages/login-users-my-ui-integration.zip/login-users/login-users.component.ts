import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { AcountService } from '../Service/acount.service';
@Component({
  selector: 'app-login-users',
  templateUrl: './login-users.component.html',
  styleUrls: ['./login-users.component.css']
})
export class LoginUsersComponent implements OnInit {
  signupusers: any[] = [];
  loginObj: any = {
    email: '',
    password: '',
  };


  
constructor(private route:Router , private http:HttpClient, private AcountService: AcountService){}

submit(){
  this.route.navigate(['/signup'])
}



ngOnInit(): void {
  const localData = localStorage.getItem('signupusers');
  if (localData != null) {
    this.signupusers = JSON.parse(localData);
  }
}
onLogin() {
  debugger;
  this.AcountService.onLogin(this.loginObj).subscribe((res: any) => {
    console.log('res', res);
    localStorage.setItem('token', res.token);
    this.route.navigateByUrl('/home');
  });
}
}
